const shopFilterData = ["shopname", "businessType","shoplicense","shopCategory","marketPlace"];
const shopItemFilterData = ["itemname","brandName", "category","subCategory", "country", "city", "state", "price" ];

module.exports = {
    shopFilterData,
    shopItemFilterData
}